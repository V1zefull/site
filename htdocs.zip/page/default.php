<!doctype html>
<html lang="ru">
 <head>
  <title>Dialogs</title>
  <meta charset="utf8">
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
  </head>
<body>

<style>

.dialog {
	cursor: pointer;
	transition: all 0.2s;
}

.dialog:hover {
	filter: hue-rotate(45deg);
}

</style>

<div class="container">
<div class="row">
<div class="col">
<!------------- NAVBAR -------------->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Dialogs</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      <a class="nav-item nav-link" href="#">Features</a>
      <a class="nav-item nav-link" href="#">Pricing</a>
      <a id="aLogout" class="nav-item nav-link" href="#">Logout</a>
    </div>
  </div>
</nav>
<!------------- END NAVBAR -------------->
<div id="dialog">
<div class="container">

<div class="row bg-light border-top border-primary p-3">
ok
</div>

<div class="container fixed-bottom msgBar">
 <div class="row">
 <div class="col">
	
		 <div class="input-group input-group-lg my-3" id="confirm">
		 	  <input id="inputMessage" type="text" class="form-control" placeholder="Message...">
	   <div class="input-group-append">
	    <button class="input-group-text" id="bSend"><i class="fas fa-paper-plane"></i></button>
	   </div>
	 </div>
	
 </div>
</div>
</div>


</div><!--container-->
</div><!-- dialog -->

<div id="dialogList">
 <div class="container border-top border-warning">
  <div class="row">
   <div class="col">
    <div id="dialogsContainer">
	</div>
   </div>
  </div>
</div><!-- dialog list -->

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>

$( function () { 
	
	$.get('ajax/dialogList.php', function (data) { 
		//$('#dialogsContainer').html(data);
		var content = "";
		data = JSON.parse(data);
		for (var i = 0; i < data.length; i++)
		{
			content += '<div did="'+data[i].id+'" class="alert alert-primary dialog mt-3">' + data[i].title +
			"</div>" + "<hr>";
		}
		$('#dialogsContainer').html(content);
		
		$('.dialog').click(function () {
			$('#dialogList').slideUp(500);
			$('#dialog').slideDown(500);
		});
		
		
	});
	
	$('#dialog').hide();

	$('#bSend').click( function () {
		var msg = $('#inputMessage').text().trim();
		if (msg.length == 0) return;
		$.post('ajax/send_message.php');
	});

	$('#aLogout').click(
		function () { 
			$.get('ajax/logout.php', function (data) {
				alert(data);
				data = JSON.parse(data);
				if (data.result == "ok") {
					window.location = "/";
				}
				
			});
		}
	);
});

</script>
</body>
</html>