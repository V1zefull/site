<button id="alert">Button</button>
<style>
button {
background: red 
}
</style>
<table>

<tr>
<td>1234</td>
<td>4321</td>
</tr>

<tr>
<td>4321</td>
<td>1234</td>
</tr>

</table>
<script src="js/jquery.min.js"></script>
<script>

$( function () {
	$('#alert').click(
		function () {
			alert()
		}
	);
});

</script>


